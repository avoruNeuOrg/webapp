require = require('esm')(module)
module.exports = require('./mainServer.js')

